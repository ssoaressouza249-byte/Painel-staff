package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DefaultAppsSeed
import com.example.data.LocalPrefsStorage
import com.example.data.RemoteStaffGuardTemplate
import com.example.security.SecurityGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name and package integrity pass`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Painel Staff", appName)

    val result = SecurityGuard.verifyIntegrity(context)
    assertTrue(result.isAuthentic)
    assertEquals("com.raylan.painelstaff", result.detectedPackage)
  }

  @Test
  fun `pin configuration and verification work securely`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val storage = LocalPrefsStorage(context)

    assertFalse(storage.hasPinConfigured())
    assertTrue(storage.savePin("123456"))
    assertTrue(storage.hasPinConfigured())
    assertTrue(storage.verifyPin("123456"))
    assertFalse(storage.verifyPin("654321"))
  }

  @Test
  fun `remote staff guard template injects firebase url and app info`() {
    val sampleApp = DefaultAppsSeed.createInitialApps().first()
    val code =
      RemoteStaffGuardTemplate.generateKotlinCode(
        firebaseBaseUrl = "https://painel-test-default-rtdb.firebaseio.com/",
        targetApp = sampleApp,
      )
    assertTrue(code.contains("https://painel-test-default-rtdb.firebaseio.com"))
    assertTrue(code.contains(sampleApp.name))
    assertTrue(code.contains(sampleApp.packageName))
  }
}
