package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AnalyticsSnapshot
import com.example.data.AntiCloneLog
import com.example.data.AppStatus
import com.example.data.DefaultAppsSeed
import com.example.data.FirebaseRestClient
import com.example.data.GlobalNotice
import com.example.data.LocalPrefsStorage
import com.example.data.ManagedApp
import com.example.data.StaffDatabaseSnapshot
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class StaffTab(val title: String, val route: String) {
  CONTROL("Controle", "tab_control"),
  ANTI_CLONE("Anti-Clone", "tab_anti_clone"),
  INTEGRATION("Integração", "tab_integration"),
  ANALYTICS("Analytics", "tab_analytics"),
}

data class StaffUiState(
  val isPinConfigured: Boolean = false,
  val isUnlocked: Boolean = false,
  val pinSetupFirstEntry: String? = null,
  val pinError: String? = null,
  val firebaseUrl: String = "",
  val isServerOnline: Boolean = false,
  val isSyncing: Boolean = false,
  val lastSyncTime: String = "",
  val connectionError: String? = null,
  val selectedTab: StaffTab = StaffTab.CONTROL,
  val apps: List<ManagedApp> = DefaultAppsSeed.createInitialApps(),
  val globalNotice: GlobalNotice = GlobalNotice(),
  val antiCloneLogs: List<AntiCloneLog> = emptyList(),
  val timelineSnapshots: List<AnalyticsSnapshot> = emptyList(),
  val selectedIntegrationAppId: String = "grx_resolucao",
  val snackbarMessage: String? = null,
  val showSettingsDialog: Boolean = false,
  val showGlobalNoticeDialog: Boolean = false,
  val showAddAppDialog: Boolean = false,
)

class StaffViewModel(application: Application) : AndroidViewModel(application) {
  private val storage = LocalPrefsStorage(application.applicationContext)
  private val restClient = FirebaseRestClient()

  private val _uiState =
    MutableStateFlow(
      StaffUiState(
        isPinConfigured = storage.hasPinConfigured(),
        firebaseUrl = storage.getFirebaseUrl(),
      )
    )
  val uiState: StateFlow<StaffUiState> = _uiState.asStateFlow()

  private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
  private val shortTimeFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

  fun onPinSubmitted(pin: String) {
    val state = _uiState.value
    if (pin.length != 6 || !pin.all { it.isDigit() }) {
      _uiState.update { it.copy(pinError = "Digite exatamente 6 dígitos numéricos.") }
      return
    }

    if (!state.isPinConfigured) {
      val first = state.pinSetupFirstEntry
      if (first == null) {
        _uiState.update {
          it.copy(
            pinSetupFirstEntry = pin,
            pinError = null,
          )
        }
      } else if (first == pin) {
        val saved = storage.savePin(pin)
        if (saved) {
          _uiState.update {
            it.copy(
              isPinConfigured = true,
              isUnlocked = true,
              pinSetupFirstEntry = null,
              pinError = null,
            )
          }
          if (itHasConfiguredUrl()) {
            syncNow(autoInitializeIfEmpty = true)
          }
        } else {
          _uiState.update {
            it.copy(pinSetupFirstEntry = null, pinError = "Falha ao salvar o PIN.")
          }
        }
      } else {
        _uiState.update {
          it.copy(
            pinSetupFirstEntry = null,
            pinError = "Os PINs não coincidem. Tente configurar novamente.",
          )
        }
      }
    } else {
      if (storage.verifyPin(pin)) {
        _uiState.update { it.copy(isUnlocked = true, pinError = null) }
        if (itHasConfiguredUrl()) {
          syncNow(autoInitializeIfEmpty = true)
        }
      } else {
        _uiState.update { it.copy(pinError = "PIN incorreto. Acesso negado.") }
      }
    }
  }

  fun resetPinSetupStep() {
    _uiState.update { it.copy(pinSetupFirstEntry = null, pinError = null) }
  }

  fun updateStaffPin(newPin: String): Boolean {
    if (newPin.length != 6 || !newPin.all { it.isDigit() }) {
      showSnackbar("O novo PIN deve ter exatamente 6 dígitos.")
      return false
    }
    val ok = storage.savePin(newPin)
    if (ok) {
      _uiState.update { it.copy(isPinConfigured = true) }
      showSnackbar("PIN Staff atualizado com segurança.")
    } else {
      showSnackbar("Erro ao atualizar o PIN.")
    }
    return ok
  }

  fun selectTab(tab: StaffTab) {
    _uiState.update { it.copy(selectedTab = tab) }
  }

  fun selectIntegrationApp(appId: String) {
    _uiState.update { it.copy(selectedIntegrationAppId = appId) }
  }

  fun setShowSettingsDialog(show: Boolean) {
    _uiState.update { it.copy(showSettingsDialog = show) }
  }

  fun setShowGlobalNoticeDialog(show: Boolean) {
    _uiState.update { it.copy(showGlobalNoticeDialog = show) }
  }

  fun setShowAddAppDialog(show: Boolean) {
    _uiState.update { it.copy(showAddAppDialog = show) }
  }

  fun clearSnackbar() {
    _uiState.update { it.copy(snackbarMessage = null) }
  }

  fun showSnackbar(message: String) {
    _uiState.update { it.copy(snackbarMessage = message) }
  }

  fun connectAndSync(rawUrl: String) {
    val normalized = restClient.normalizeBaseUrl(rawUrl)
    if (normalized.isBlank() || (!normalized.startsWith("https://") && !normalized.startsWith("http://"))) {
      _uiState.update {
        it.copy(
          connectionError = "Informe uma URL válida do Firebase Realtime Database (ex: https://projeto.firebaseio.com).",
          isServerOnline = false,
        )
      }
      return
    }
    storage.saveFirebaseUrl(normalized)
    _uiState.update {
      it.copy(
        firebaseUrl = normalized,
        connectionError = null,
        showSettingsDialog = false,
      )
    }
    syncNow(autoInitializeIfEmpty = true)
  }

  fun syncNow(autoInitializeIfEmpty: Boolean = false) {
    val url = _uiState.value.firebaseUrl
    if (url.isBlank()) {
      _uiState.update { it.copy(isServerOnline = false, isSyncing = false) }
      return
    }

    viewModelScope.launch {
      _uiState.update { it.copy(isSyncing = true) }
      val result =
        if (autoInitializeIfEmpty) {
          restClient.fetchOrInitializeDatabase(url)
        } else {
          restClient.fetchSnapshot(url)
        }

      result
        .onSuccess { snapshot -> applySnapshot(snapshot) }
        .onFailure { error ->
          _uiState.update {
            it.copy(
              isServerOnline = false,
              isSyncing = false,
              connectionError = error.message ?: "Falha ao conectar ao servidor.",
            )
          }
        }
    }
  }

  private fun applySnapshot(snapshot: StaffDatabaseSnapshot) {
    val now = System.currentTimeMillis()
    val totalOnline = snapshot.apps.sumOf { it.onlineUsers }
    val totalAccesses = snapshot.apps.sumOf { maxOf(it.totalAccesses, it.totalInstalls) }
    val newPoint =
      AnalyticsSnapshot(
        label = shortTimeFormatter.format(Date(now)),
        onlineUsers = totalOnline,
        totalAccesses = totalAccesses,
        timestamp = now,
      )

    _uiState.update { current ->
      val combinedTimeline =
        if (snapshot.serverTimeline.isNotEmpty()) {
          (snapshot.serverTimeline + newPoint).takeLast(14)
        } else {
          (current.timelineSnapshots + newPoint).takeLast(14)
        }

      val validIntegrationId =
        if (snapshot.apps.any { it.id == current.selectedIntegrationAppId }) {
          current.selectedIntegrationAppId
        } else {
          snapshot.apps.firstOrNull()?.id ?: "grx_resolucao"
        }

      current.copy(
        isServerOnline = true,
        isSyncing = false,
        lastSyncTime = timeFormatter.format(Date(now)),
        connectionError = null,
        apps = snapshot.apps,
        globalNotice = snapshot.globalNotice,
        antiCloneLogs = snapshot.antiCloneLogs,
        timelineSnapshots = combinedTimeline,
        selectedIntegrationAppId = validIntegrationId,
      )
    }
  }

  fun updateAppStatus(app: ManagedApp, newStatus: AppStatus, noticeMessage: String) {
    val url = _uiState.value.firebaseUrl
    if (url.isBlank()) {
      showSnackbar("Configure a URL do Firebase na engrenagem primeiro.")
      _uiState.update { it.copy(showSettingsDialog = true) }
      return
    }

    // Optimistic local update for instant responsiveness
    _uiState.update { state ->
      state.copy(
        apps =
          state.apps.map {
            if (it.id == app.id) {
              it.copy(
                status = newStatus,
                noticeMessage = noticeMessage,
                updatedAt = System.currentTimeMillis(),
              )
            } else {
              it
            }
          }
      )
    }

    viewModelScope.launch {
      restClient
        .updateAppStatus(url, app.id, newStatus, noticeMessage)
        .onSuccess {
          showSnackbar("${app.name} atualizado para ${newStatus.label}.")
          syncNow(autoInitializeIfEmpty = false)
        }
        .onFailure { err ->
          showSnackbar("Erro ao salvar online: ${err.message ?: "verifique a URL"}")
        }
    }
  }

  fun saveAppNotice(app: ManagedApp, noticeMessage: String) {
    val url = _uiState.value.firebaseUrl
    if (url.isBlank()) {
      showSnackbar("Configure a URL do Firebase na engrenagem primeiro.")
      _uiState.update { it.copy(showSettingsDialog = true) }
      return
    }

    _uiState.update { state ->
      state.copy(
        apps =
          state.apps.map {
            if (it.id == app.id) {
              it.copy(noticeMessage = noticeMessage, updatedAt = System.currentTimeMillis())
            } else {
              it
            }
          }
      )
    }

    viewModelScope.launch {
      restClient
        .updateAppNotice(url, app.id, noticeMessage)
        .onSuccess { showSnackbar("Aviso de ${app.name} salvo online.") }
        .onFailure { err ->
          showSnackbar("Erro ao salvar aviso: ${err.message ?: "falha de rede"}")
        }
    }
  }

  fun addNewApp(name: String, packageName: String, initialNotice: String) {
    val cleanName = name.trim()
    val cleanPkg = packageName.trim()
    if (cleanName.isBlank()) {
      showSnackbar("Informe o nome do aplicativo.")
      return
    }
    val url = _uiState.value.firebaseUrl
    if (url.isBlank()) {
      showSnackbar("Configure a URL do Firebase na engrenagem primeiro.")
      _uiState.update { it.copy(showAddAppDialog = false, showSettingsDialog = true) }
      return
    }

    val generatedId =
      cleanName
        .lowercase(Locale.getDefault())
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .ifBlank { "app_${System.currentTimeMillis()}" }

    val resolvedPkg =
      cleanPkg.ifBlank { "com.raylan.${generatedId.replace("_", "")}" }

    val newApp =
      ManagedApp(
        id = generatedId,
        name = cleanName,
        packageName = resolvedPkg,
        status = AppStatus.ONLINE,
        noticeMessage = initialNotice.trim(),
        totalInstalls = 0,
        onlineUsers = 0,
        totalAccesses = 0,
        updatedAt = System.currentTimeMillis(),
      )

    viewModelScope.launch {
      restClient
        .upsertApp(url, newApp)
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              apps = state.apps.filterNot { it.id == newApp.id } + newApp,
              showAddAppDialog = false,
            )
          }
          showSnackbar("${newApp.name} adicionado e sincronizado!")
          syncNow(autoInitializeIfEmpty = false)
        }
        .onFailure { err ->
          showSnackbar("Erro ao adicionar app: ${err.message ?: "falha de rede"}")
        }
    }
  }

  fun sendGlobalNotice(message: String, active: Boolean) {
    val url = _uiState.value.firebaseUrl
    if (url.isBlank()) {
      showSnackbar("Configure a URL do Firebase na engrenagem primeiro.")
      _uiState.update { it.copy(showGlobalNoticeDialog = false, showSettingsDialog = true) }
      return
    }

    val notice =
      GlobalNotice(
        message = message.trim(),
        active = active && message.isNotBlank(),
        updatedAt = System.currentTimeMillis(),
      )

    viewModelScope.launch {
      restClient
        .sendGlobalNotice(url, notice)
        .onSuccess {
          _uiState.update {
            it.copy(globalNotice = notice, showGlobalNoticeDialog = false)
          }
          showSnackbar(
            if (notice.active) "Aviso global enviado para todos os apps!"
            else "Aviso global desativado."
          )
        }
        .onFailure { err ->
          showSnackbar("Erro ao enviar aviso global: ${err.message ?: "falha"}")
        }
    }
  }

  fun setCloneBlocked(log: AntiCloneLog, blocked: Boolean) {
    val url = _uiState.value.firebaseUrl
    if (url.isBlank()) {
      showSnackbar("Configure a URL do Firebase primeiro.")
      return
    }

    viewModelScope.launch {
      restClient
        .setCloneBlocked(url, log, blocked)
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              antiCloneLogs =
                state.antiCloneLogs.map {
                  if (it.id == log.id) it.copy(blocked = blocked) else it
                }
            )
          }
          showSnackbar(
            if (blocked) "Clone bloqueado remotamente (blocked = true)!"
            else "Bloqueio removido."
          )
        }
        .onFailure { err ->
          showSnackbar("Erro ao atualizar bloqueio: ${err.message ?: "falha"}")
        }
    }
  }

  fun clearAntiCloneLogs() {
    val url = _uiState.value.firebaseUrl
    if (url.isBlank()) {
      showSnackbar("Configure a URL do Firebase primeiro.")
      return
    }

    viewModelScope.launch {
      restClient
        .clearAntiCloneLogs(url)
        .onSuccess {
          _uiState.update { it.copy(antiCloneLogs = emptyList()) }
          showSnackbar("Logs de tentativas anti-clone limpos.")
        }
        .onFailure { err ->
          showSnackbar("Erro ao limpar logs: ${err.message ?: "falha"}")
        }
    }
  }

  private fun itHasConfiguredUrl(): Boolean = _uiState.value.firebaseUrl.isNotBlank()
}
