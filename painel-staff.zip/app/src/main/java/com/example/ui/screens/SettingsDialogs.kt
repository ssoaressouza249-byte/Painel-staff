package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.GlobalNotice
import com.example.ui.components.NeonBorderBrush
import com.example.ui.theme.DarkCardBg
import com.example.ui.theme.DarkInputBg
import com.example.ui.theme.DeepBlackBg
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.theme.StatusUnavailableRed
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite

@Composable
fun FirebaseSettingsDialog(
  currentUrl: String,
  connectionError: String?,
  onDismiss: () -> Unit,
  onConnectAndSync: (String) -> Unit,
  onUpdatePin: (String) -> Boolean,
) {
  var urlInput by remember(currentUrl) { mutableStateOf(currentUrl) }
  var newPinInput by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(DarkCardBg, RoundedCornerShape(18.dp))
          .border(1.2.dp, NeonBorderBrush, RoundedCornerShape(18.dp))
          .padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = "Configurar Firebase Realtime DB",
        style = MaterialTheme.typography.titleLarge,
        color = TextWhite,
        fontWeight = FontWeight.Bold,
      )

      Text(
        text =
          "Cole a URL do seu Firebase Realtime Database (REST sem google-services.json). Ao conectar, o banco será inicializado automaticamente se estiver vazio.",
        style = MaterialTheme.typography.bodyMedium,
        color = TextGray,
      )

      OutlinedTextField(
        value = urlInput,
        onValueChange = { urlInput = it },
        label = { Text("URL do Firebase RTDB") },
        placeholder = { Text("https://seu-projeto-default-rtdb.firebaseio.com") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("firebase_url_input"),
        colors = darkNeonFieldColors(),
      )

      if (!connectionError.isNullOrBlank()) {
        Text(
          text = connectionError,
          color = StatusUnavailableRed,
          style = MaterialTheme.typography.bodyMedium,
        )
      }

      Button(
        onClick = { onConnectAndSync(urlInput) },
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("connect_sync_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple, contentColor = TextWhite),
      ) {
        Icon(Icons.Filled.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("Conectar & Sincronizar Agora", fontWeight = FontWeight.Bold)
      }

      HorizontalDivider(color = ElectricBlue.copy(alpha = 0.25f))

      Text(
        text = "Alterar PIN Staff (6 dígitos)",
        style = MaterialTheme.typography.titleMedium,
        color = TextWhite,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = newPinInput,
          onValueChange = { txt ->
            if (txt.length <= 6 && txt.all { it.isDigit() }) newPinInput = txt
          },
          label = { Text("Novo PIN") },
          placeholder = { Text("000000") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
          modifier = Modifier.weight(1f).testTag("change_pin_input"),
          colors = darkNeonFieldColors(),
        )
        OutlinedButton(
          onClick = {
            if (onUpdatePin(newPinInput)) {
              newPinInput = ""
            }
          },
          modifier = Modifier.height(52.dp).testTag("save_new_pin_button"),
          shape = RoundedCornerShape(12.dp),
        ) {
          Icon(Icons.Filled.Key, contentDescription = "Salvar PIN", tint = ElectricBlue, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Salvar", color = ElectricBlue, fontSize = 12.sp)
        }
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        TextButton(onClick = onDismiss) {
          Text("Fechar", color = TextGray)
        }
      }
    }
  }
}

@Composable
fun GlobalNoticeDialog(
  currentNotice: GlobalNotice,
  onDismiss: () -> Unit,
  onSendGlobalNotice: (String, Boolean) -> Unit,
) {
  var messageText by remember(currentNotice) { mutableStateOf(currentNotice.message) }

  Dialog(onDismissRequest = onDismiss) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(DarkCardBg, RoundedCornerShape(18.dp))
          .border(1.2.dp, NeonBorderBrush, RoundedCornerShape(18.dp))
          .padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = "Enviar Aviso Global",
        style = MaterialTheme.typography.titleLarge,
        color = TextWhite,
        fontWeight = FontWeight.Bold,
      )

      Text(
        text =
          "Este banner/notificação será exibido instantaneamente em todos os aplicativos clientes conectados.",
        style = MaterialTheme.typography.bodyMedium,
        color = TextGray,
      )

      OutlinedTextField(
        value = messageText,
        onValueChange = { messageText = it },
        label = { Text("Mensagem do Aviso Global") },
        placeholder = { Text("Ex: Nova atualização disponível para todos os usuários!") },
        minLines = 3,
        maxLines = 5,
        modifier = Modifier.fillMaxWidth().testTag("global_notice_input"),
        colors = darkNeonFieldColors(),
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        if (currentNotice.active) {
          OutlinedButton(
            onClick = { onSendGlobalNotice("", false) },
            modifier = Modifier.weight(1f).height(48.dp).testTag("disable_global_notice_button"),
            shape = RoundedCornerShape(12.dp),
          ) {
            Text("Desativar", color = StatusUnavailableRed, fontWeight = FontWeight.Bold)
          }
        }
        Button(
          onClick = { onSendGlobalNotice(messageText, true) },
          modifier = Modifier.weight(1f).height(48.dp).testTag("send_global_notice_confirm_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = DeepBlackBg),
        ) {
          Text("Enviar Agora", fontWeight = FontWeight.ExtraBold)
        }
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        TextButton(onClick = onDismiss) {
          Text("Cancelar", color = TextGray)
        }
      }
    }
  }
}

@Composable
fun AddAppDialog(
  onDismiss: () -> Unit,
  onAddApp: (name: String, packageName: String, initialNotice: String) -> Unit,
) {
  var appName by remember { mutableStateOf("") }
  var packageName by remember { mutableStateOf("") }
  var initialNotice by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(DarkCardBg, RoundedCornerShape(18.dp))
          .border(1.2.dp, NeonBorderBrush, RoundedCornerShape(18.dp))
          .padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = "Adicionar Novo App",
        style = MaterialTheme.typography.titleLarge,
        color = TextWhite,
        fontWeight = FontWeight.Bold,
      )

      OutlinedTextField(
        value = appName,
        onValueChange = { appName = it },
        label = { Text("Nome do Aplicativo") },
        placeholder = { Text("Ex: Rayze Turbo Pro") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("new_app_name_input"),
        colors = darkNeonFieldColors(),
      )

      OutlinedTextField(
        value = packageName,
        onValueChange = { packageName = it },
        label = { Text("Package Name (opcional)") },
        placeholder = { Text("com.raylan.novoapp") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("new_app_package_input"),
        colors = darkNeonFieldColors(),
      )

      OutlinedTextField(
        value = initialNotice,
        onValueChange = { initialNotice = it },
        label = { Text("Aviso inicial (opcional)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("new_app_notice_input"),
        colors = darkNeonFieldColors(),
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        TextButton(
          onClick = onDismiss,
          modifier = Modifier.weight(1f).height(48.dp),
        ) {
          Text("Cancelar", color = TextGray)
        }
        Button(
          onClick = { onAddApp(appName, packageName, initialNotice) },
          modifier = Modifier.weight(1f).height(48.dp).testTag("confirm_add_app_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = StatusOnlineGreen, contentColor = DeepBlackBg),
        ) {
          Text("Salvar Online", fontFamily = FontFamily.Default, fontWeight = FontWeight.ExtraBold)
        }
      }
    }
  }
}

@Composable
fun darkNeonFieldColors() =
  OutlinedTextFieldDefaults.colors(
    focusedContainerColor = DarkInputBg,
    unfocusedContainerColor = DarkInputBg,
    focusedTextColor = TextWhite,
    unfocusedTextColor = TextWhite,
    focusedBorderColor = ElectricBlue,
    unfocusedBorderColor = NeonPurple.copy(alpha = 0.55f),
    focusedLabelColor = ElectricBlue,
    unfocusedLabelColor = TextGray,
    cursorColor = ElectricBlue,
    focusedPlaceholderColor = TextGray.copy(alpha = 0.6f),
    unfocusedPlaceholderColor = TextGray.copy(alpha = 0.6f),
  )
