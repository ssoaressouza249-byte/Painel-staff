package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.security.SecurityGuard
import com.example.security.SecurityTamperScreen
import com.example.ui.components.NeonBorderBrush
import com.example.ui.components.ServerStatusBadge
import com.example.ui.components.StaffBrandFooter
import com.example.ui.screens.AddAppDialog
import com.example.ui.screens.AnalyticsTab
import com.example.ui.screens.AntiCloneTab
import com.example.ui.screens.ControlTab
import com.example.ui.screens.FirebaseSettingsDialog
import com.example.ui.screens.GlobalNoticeDialog
import com.example.ui.screens.IntegrationTab
import com.example.ui.screens.PinLockScreen
import com.example.ui.theme.DarkCardBg
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DeepBlackBg
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StatusUnavailableRed
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@Composable
fun PainelStaffApp(staffViewModel: StaffViewModel = viewModel()) {
  val context = LocalContext.current
  val securityResult = remember { SecurityGuard.verifyIntegrity(context) }

  if (!securityResult.isAuthentic) {
    SecurityTamperScreen(result = securityResult)
    return
  }

  val uiState by staffViewModel.uiState.collectAsStateWithLifecycle()

  if (!uiState.isUnlocked) {
    PinLockScreen(
      isPinConfigured = uiState.isPinConfigured,
      isConfirmingSetup = uiState.pinSetupFirstEntry != null,
      pinError = uiState.pinError,
      onSubmitPin = staffViewModel::onPinSubmitted,
      onResetSetup = staffViewModel::resetPinSetupStep,
    )
    return
  }

  // Real-time auto-refresh every 5 seconds while unlocked and Firebase URL is set
  LaunchedEffect(uiState.isUnlocked, uiState.firebaseUrl) {
    if (uiState.firebaseUrl.isNotBlank()) {
      while (isActive) {
        delay(5000)
        staffViewModel.syncNow(autoInitializeIfEmpty = false)
      }
    }
  }

  val snackbarHostState = remember { SnackbarHostState() }
  LaunchedEffect(uiState.snackbarMessage) {
    val msg = uiState.snackbarMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      staffViewModel.clearSnackbar()
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize().background(DeepBlackBg),
    containerColor = DeepBlackBg,
    contentWindowInsets = WindowInsets.safeDrawing,
    snackbarHost = {
      SnackbarHost(hostState = snackbarHostState) { data ->
        Snackbar(
          snackbarData = data,
          containerColor = DarkCardElevated,
          contentColor = TextWhite,
          shape = RoundedCornerShape(12.dp),
        )
      }
    },
    topBar = {
      StaffTopBar(
        isServerOnline = uiState.isServerOnline,
        isSyncing = uiState.isSyncing,
        onBadgeOrSettingsClick = { staffViewModel.setShowSettingsDialog(true) },
        onManualRefresh = { staffViewModel.syncNow(autoInitializeIfEmpty = false) },
      )
    },
    bottomBar = {
      StaffBottomBar(
        selectedTab = uiState.selectedTab,
        unblockedAlertsCount = uiState.antiCloneLogs.count { !it.blocked },
        onSelectTab = staffViewModel::selectTab,
      )
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .padding(innerPadding)
          .background(
            Brush.verticalGradient(
              colors = listOf(DeepBlackBg, DarkCardBg.copy(alpha = 0.45f), DeepBlackBg)
            )
          ),
      contentAlignment = Alignment.TopCenter,
    ) {
      Box(modifier = Modifier.fillMaxSize().widthIn(max = 760.dp)) {
        when (uiState.selectedTab) {
          StaffTab.CONTROL ->
            ControlTab(
              apps = uiState.apps,
              globalNotice = uiState.globalNotice,
              isServerOnline = uiState.isServerOnline,
              onStatusChange = staffViewModel::updateAppStatus,
              onSaveNotice = staffViewModel::saveAppNotice,
              onOpenGlobalNotice = { staffViewModel.setShowGlobalNoticeDialog(true) },
              onOpenAddApp = { staffViewModel.setShowAddAppDialog(true) },
            )
          StaffTab.ANTI_CLONE ->
            AntiCloneTab(
              logs = uiState.antiCloneLogs,
              onBlockClone = staffViewModel::setCloneBlocked,
              onClearLogs = staffViewModel::clearAntiCloneLogs,
            )
          StaffTab.INTEGRATION ->
            IntegrationTab(
              apps = uiState.apps,
              selectedAppId = uiState.selectedIntegrationAppId,
              firebaseUrl = uiState.firebaseUrl,
              onSelectApp = staffViewModel::selectIntegrationApp,
              onCopiedFeedback = staffViewModel::showSnackbar,
            )
          StaffTab.ANALYTICS ->
            AnalyticsTab(
              apps = uiState.apps,
              timeline = uiState.timelineSnapshots,
              antiCloneLogs = uiState.antiCloneLogs,
              lastSyncTime = uiState.lastSyncTime,
            )
        }
      }
    }
  }

  if (uiState.showSettingsDialog) {
    FirebaseSettingsDialog(
      currentUrl = uiState.firebaseUrl,
      connectionError = uiState.connectionError,
      onDismiss = { staffViewModel.setShowSettingsDialog(false) },
      onConnectAndSync = staffViewModel::connectAndSync,
      onUpdatePin = staffViewModel::updateStaffPin,
    )
  }

  if (uiState.showGlobalNoticeDialog) {
    GlobalNoticeDialog(
      currentNotice = uiState.globalNotice,
      onDismiss = { staffViewModel.setShowGlobalNoticeDialog(false) },
      onSendGlobalNotice = staffViewModel::sendGlobalNotice,
    )
  }

  if (uiState.showAddAppDialog) {
    AddAppDialog(
      onDismiss = { staffViewModel.setShowAddAppDialog(false) },
      onAddApp = staffViewModel::addNewApp,
    )
  }
}

@Composable
private fun StaffTopBar(
  isServerOnline: Boolean,
  isSyncing: Boolean,
  onBadgeOrSettingsClick: () -> Unit,
  onManualRefresh: () -> Unit,
) {
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .background(DarkCardBg)
        .statusBarsPadding()
        .padding(horizontal = 14.dp, vertical = 10.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = "PAINEL STAFF — Criado por Raylan",
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.ExtraBold,
          fontSize = 13.sp,
          color = TextWhite,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(5.dp))
        ServerStatusBadge(
          isOnline = isServerOnline,
          isSyncing = isSyncing,
          onClick = onBadgeOrSettingsClick,
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        IconButton(
          onClick = onManualRefresh,
          modifier =
            Modifier.size(48.dp)
              .clip(CircleShape)
              .background(DarkCardElevated)
              .border(1.dp, ElectricBlue.copy(alpha = 0.45f), CircleShape)
              .testTag("manual_refresh_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Refresh,
            contentDescription = "Sincronizar Agora",
            tint = ElectricBlue,
            modifier = Modifier.size(20.dp),
          )
        }

        IconButton(
          onClick = onBadgeOrSettingsClick,
          modifier =
            Modifier.size(48.dp)
              .clip(CircleShape)
              .background(DarkCardElevated)
              .border(1.dp, NeonBorderBrush, CircleShape)
              .testTag("settings_gear_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Settings,
            contentDescription = "Configurar Firebase URL",
            tint = TextWhite,
            modifier = Modifier.size(22.dp),
          )
        }
      }
    }
    Spacer(modifier = Modifier.height(8.dp))
    HorizontalDivider(
      thickness = 1.dp,
      color = NeonPurple.copy(alpha = 0.45f),
    )
  }
}

@Composable
private fun StaffBottomBar(
  selectedTab: StaffTab,
  unblockedAlertsCount: Int,
  onSelectTab: (StaffTab) -> Unit,
) {
  Column(
    modifier = Modifier.fillMaxWidth().background(DarkCardBg).navigationBarsPadding(),
  ) {
    HorizontalDivider(
      thickness = 1.dp,
      color = ElectricBlue.copy(alpha = 0.35f),
    )
    NavigationBar(
      containerColor = DarkCardBg,
      contentColor = TextWhite,
      tonalElevation = 0.dp,
      windowInsets = WindowInsets(0, 0, 0, 0),
    ) {
      StaffTab.entries.forEach { tab ->
        val selected = tab == selectedTab
        val icon =
          when (tab) {
            StaffTab.CONTROL -> if (selected) Icons.Filled.Dashboard else Icons.Outlined.Dashboard
            StaffTab.ANTI_CLONE -> if (selected) Icons.Filled.Security else Icons.Outlined.Security
            StaffTab.INTEGRATION -> if (selected) Icons.Filled.Code else Icons.Outlined.Code
            StaffTab.ANALYTICS -> if (selected) Icons.Filled.Analytics else Icons.Outlined.Analytics
          }

        NavigationBarItem(
          selected = selected,
          onClick = { onSelectTab(tab) },
          modifier = Modifier.testTag(tab.route),
          icon = {
            if (tab == StaffTab.ANTI_CLONE && unblockedAlertsCount > 0) {
              BadgedBox(
                badge = {
                  Badge(containerColor = StatusUnavailableRed, contentColor = TextWhite) {
                    Text(unblockedAlertsCount.toString(), fontSize = 10.sp)
                  }
                }
              ) {
                Icon(imageVector = icon, contentDescription = tab.title)
              }
            } else {
              Icon(imageVector = icon, contentDescription = tab.title)
            }
          },
          label = {
            Text(
              text = tab.title,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          },
          colors =
            NavigationBarItemDefaults.colors(
              selectedIconColor = ElectricBlue,
              selectedTextColor = TextWhite,
              indicatorColor = NeonPurple.copy(alpha = 0.25f),
              unselectedIconColor = TextGray,
              unselectedTextColor = TextGray,
            ),
        )
      }
    }
    StaffBrandFooter()
  }
}
