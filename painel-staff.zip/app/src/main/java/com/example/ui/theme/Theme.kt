package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val PainelDarkColorScheme =
  darkColorScheme(
    primary = NeonPurple,
    onPrimary = TextWhite,
    primaryContainer = DarkCardElevated,
    onPrimaryContainer = TextWhite,
    secondary = ElectricBlue,
    onSecondary = DeepBlackBg,
    secondaryContainer = DarkCardElevated,
    onSecondaryContainer = TextWhite,
    tertiary = StatusOnlineGreen,
    background = DeepBlackBg,
    onBackground = TextWhite,
    surface = DarkCardBg,
    onSurface = TextWhite,
    surfaceVariant = DarkCardElevated,
    onSurfaceVariant = TextGray,
    outline = NeonPurple,
    error = StatusUnavailableRed,
    onError = TextWhite,
  )

private val PainelShapes =
  Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp),
  )

@Composable
fun PainelStaffTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = PainelDarkColorScheme,
    typography = PainelTypography,
    shapes = PainelShapes,
    content = content,
  )
}
