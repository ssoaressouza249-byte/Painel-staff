package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppStatus
import com.example.data.GlobalNotice
import com.example.data.ManagedApp
import com.example.ui.components.NeonCard
import com.example.ui.components.PulsingStatusDot
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DeepBlackBg
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StatusMaintenanceOrange
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite

@Composable
fun ControlTab(
  apps: List<ManagedApp>,
  globalNotice: GlobalNotice,
  isServerOnline: Boolean,
  onStatusChange: (ManagedApp, AppStatus, String) -> Unit,
  onSaveNotice: (ManagedApp, String) -> Unit,
  onOpenGlobalNotice: () -> Unit,
  onOpenAddApp: () -> Unit,
) {
  val totalInstalls = remember(apps) { apps.sumOf { it.totalInstalls } }
  val totalOnlineNow = remember(apps) { apps.sumOf { it.onlineUsers } }
  val activeAppsCount = remember(apps) { apps.count { it.status == AppStatus.ONLINE } }
  val maintenanceAppsCount = remember(apps) { apps.count { it.status == AppStatus.MAINTENANCE } }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("control_tab_list"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    // Top Dashboard
    item(key = "dashboard_summary") {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          DashboardMetricCard(
            title = "TOTAL INSTALAÇÕES",
            value = totalInstalls.toString(),
            accentColor = ElectricBlue,
            icon = {
              Icon(
                imageVector = Icons.Filled.Download,
                contentDescription = "Total de Instalações",
                tint = ElectricBlue,
                modifier = Modifier.size(18.dp),
              )
            },
            modifier = Modifier.weight(1f),
          )
          DashboardMetricCard(
            title = "USUÁRIOS ONLINE",
            value = totalOnlineNow.toString(),
            accentColor = StatusOnlineGreen,
            icon = { PulsingStatusDot(color = StatusOnlineGreen, size = 10.dp, animate = true) },
            modifier = Modifier.weight(1f),
          )
        }

        NeonCard(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "STATUS DA FROTA DE APPS",
                style = MaterialTheme.typography.labelMedium,
                color = TextGray,
              )
              Spacer(modifier = Modifier.height(4.dp))
              Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = "$activeAppsCount Ativos",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = StatusOnlineGreen,
                )
                Text(
                  text = "•",
                  color = TextGray,
                )
                Text(
                  text = "$maintenanceAppsCount Manutenção",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = StatusMaintenanceOrange,
                )
              }
            }

            Button(
              onClick = onOpenGlobalNotice,
              modifier = Modifier.height(44.dp).testTag("open_global_notice_button"),
              shape = RoundedCornerShape(10.dp),
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = NeonPurple,
                  contentColor = TextWhite,
                ),
              contentPadding = PaddingValues(horizontal = 12.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.Campaign,
                contentDescription = "Aviso Global",
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Enviar Aviso Global",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
              )
            }
          }
        }

        if (globalNotice.active && globalNotice.message.isNotBlank()) {
          NeonCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = NeonPurple.copy(alpha = 0.12f),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.Campaign,
                contentDescription = "Banner Global Ativo",
                tint = ElectricBlue,
                modifier = Modifier.size(20.dp),
              )
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "AVISO GLOBAL ATIVO",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp,
                  color = ElectricBlue,
                )
                Text(
                  text = globalNotice.message,
                  style = MaterialTheme.typography.bodyMedium,
                  color = TextWhite,
                )
              }
            }
          }
        }
      }
    }

    // Section Header + Add App Button
    item(key = "apps_header") {
      Row(
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "Aplicativos Conectados (${apps.size})",
            style = MaterialTheme.typography.titleLarge,
            color = TextWhite,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text =
              if (isServerOnline) "Alterações salvas instantaneamente no Firebase"
              else "Configure a URL na engrenagem para sincronizar online",
            style = MaterialTheme.typography.bodyMedium,
            color = TextGray,
          )
        }

        OutlinedButton(
          onClick = onOpenAddApp,
          modifier = Modifier.height(44.dp).testTag("add_app_button"),
          shape = RoundedCornerShape(10.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Add,
            contentDescription = "Adicionar App",
            tint = ElectricBlue,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "+ Adicionar App",
            color = ElectricBlue,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
          )
        }
      }
    }

    // Individual App Cards
    items(items = apps, key = { it.id }) { app ->
      AppControlCard(
        app = app,
        onStatusSelected = { newStatus, message -> onStatusChange(app, newStatus, message) },
        onSaveNotice = { message -> onSaveNotice(app, message) },
      )
    }

    item(key = "bottom_spacer") { Spacer(modifier = Modifier.height(8.dp)) }
  }
}

@Composable
private fun DashboardMetricCard(
  title: String,
  value: String,
  accentColor: Color,
  icon: @Composable () -> Unit,
  modifier: Modifier = Modifier,
) {
  NeonCard(modifier = modifier) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.labelSmall,
          color = TextGray,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        icon()
      }
      Text(
        text = value,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 24.sp,
        color = accentColor,
      )
    }
  }
}

@Composable
private fun AppControlCard(
  app: ManagedApp,
  onStatusSelected: (AppStatus, String) -> Unit,
  onSaveNotice: (String) -> Unit,
) {
  var noticeDraft by remember(app.id, app.noticeMessage) { mutableStateOf(app.noticeMessage) }

  NeonCard(
    modifier = Modifier.fillMaxWidth().testTag("app_card_${app.id}"),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      // Header Row: App Name + Status Pill
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = app.name,
            style = MaterialTheme.typography.titleMedium,
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = app.packageName,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = TextGray,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Box(
          modifier =
            Modifier.clip(RoundedCornerShape(50))
              .background(app.status.color.copy(alpha = 0.16f))
              .border(1.dp, app.status.color.copy(alpha = 0.7f), RoundedCornerShape(50))
              .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text = app.status.label,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = app.status.color,
          )
        }
      }

      // Live Telemetry Row: Installs & Online Now
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .background(DarkCardElevated, RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Download,
            contentDescription = "Instalações",
            tint = ElectricBlue,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = "Instalações: ${app.totalInstalls}",
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextWhite,
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          PulsingStatusDot(
            color = StatusOnlineGreen,
            size = 8.dp,
            animate = app.onlineUsers > 0,
          )
          Icon(
            imageVector = Icons.Filled.Group,
            contentDescription = "Online agora",
            tint = StatusOnlineGreen,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = "Online: ${app.onlineUsers}",
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = StatusOnlineGreen,
          )
        }
      }

      // Notice Message Input + Save Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = noticeDraft,
          onValueChange = { noticeDraft = it },
          label = { Text("Mensagem de Aviso", fontSize = 12.sp) },
          placeholder = { Text("Ex: Servidor em atualização...", fontSize = 12.sp) },
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("notice_input_${app.id}"),
          colors = darkNeonFieldColors(),
        )
        IconButton(
          onClick = { onSaveNotice(noticeDraft) },
          modifier =
            Modifier.size(48.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(ElectricBlue.copy(alpha = 0.16f))
              .border(1.dp, ElectricBlue.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
              .testTag("save_notice_button_${app.id}"),
        ) {
          Icon(
            imageVector = Icons.Filled.Save,
            contentDescription = "Salvar Mensagem de Aviso",
            tint = ElectricBlue,
          )
        }
      }

      // 3 Instant Status Buttons: ONLINE / MANUTENÇÃO / INDISPONÍVEL
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        AppStatus.entries.forEach { targetStatus ->
          val isSelected = app.status == targetStatus
          Box(
            modifier =
              Modifier.weight(1f)
                .height(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                  if (isSelected) targetStatus.color else targetStatus.color.copy(alpha = 0.12f)
                )
                .border(
                  width = 1.dp,
                  color = targetStatus.color.copy(alpha = if (isSelected) 1f else 0.55f),
                  shape = RoundedCornerShape(10.dp),
                )
                .clickable { onStatusSelected(targetStatus, noticeDraft) }
                .testTag("status_btn_${app.id}_${targetStatus.wireValue}"),
            contentAlignment = Alignment.Center,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center,
              modifier = Modifier.padding(horizontal = 4.dp),
            ) {
              if (isSelected) {
                Icon(
                  imageVector = Icons.Filled.Check,
                  contentDescription = null,
                  tint = DeepBlackBg,
                  modifier = Modifier.size(14.dp),
                )
                Spacer(modifier = Modifier.width(3.dp))
              }
              Text(
                text = targetStatus.label,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 10.sp,
                color = if (isSelected) DeepBlackBg else targetStatus.color,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }
      }
    }
  }
}
