package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep black background and ultralight dark card surfaces
val DeepBlackBg = Color(0xFF07080D)
val DarkCardBg = Color(0xFF10121B)
val DarkCardElevated = Color(0xFF161926)
val DarkInputBg = Color(0xFF0C0E16)

// Neon Purple & Electric Blue accents
val NeonPurple = Color(0xFF9D4EDD)
val NeonPurpleSoft = Color(0x339D4EDD)
val ElectricBlue = Color(0xFF00B4D8)
val ElectricBlueSoft = Color(0x3300B4D8)

// Crisp typography colors
val TextWhite = Color(0xFFF8F9FA)
val TextGray = Color(0xFFADB5BD)
val TextMuted = Color(0xFF6C757D)

// Status & alert colors
val StatusOnlineGreen = Color(0xFF00E676)
val StatusMaintenanceOrange = Color(0xFFFF9100)
val StatusUnavailableRed = Color(0xFFFF1744)
val StatusWarningYellow = Color(0xFFFFD600)
val SecurityTamperRed = Color(0xFFB71C1C)
val SecurityTamperDarkRed = Color(0xFF7F0000)
