package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkCardBg
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.theme.StatusWarningYellow
import com.example.ui.theme.TextMuted

val NeonBorderBrush: Brush =
  Brush.linearGradient(colors = listOf(NeonPurple.copy(alpha = 0.85f), ElectricBlue.copy(alpha = 0.85f)))

@Composable
fun NeonCard(
  modifier: Modifier = Modifier,
  cornerRadius: Dp = 14.dp,
  borderBrush: Brush = NeonBorderBrush,
  backgroundColor: Color = DarkCardBg,
  content: @Composable ColumnScope.() -> Unit,
) {
  val shape = RoundedCornerShape(cornerRadius)
  Column(
    modifier =
      modifier
        .clip(shape)
        .background(backgroundColor, shape)
        .border(width = 1.dp, brush = borderBrush, shape = shape),
    content = content,
  )
}

@Composable
fun PulsingStatusDot(
  color: Color = StatusOnlineGreen,
  size: Dp = 9.dp,
  animate: Boolean = true,
) {
  val infiniteTransition = rememberInfiniteTransition(label = "pulse_dot")
  val alpha by
    infiniteTransition.animateFloat(
      initialValue = 1f,
      targetValue = if (animate) 0.25f else 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "pulse_alpha",
    )

  Box(
    modifier =
      Modifier.size(size)
        .alpha(alpha)
        .background(color, CircleShape)
  )
}

@Composable
fun ServerStatusBadge(
  isOnline: Boolean,
  isSyncing: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val accentColor = if (isOnline) StatusOnlineGreen else StatusWarningYellow
  val label =
    when {
      isOnline -> "SERVIDOR ONLINE ●"
      isSyncing -> "CONECTANDO..."
      else -> "OFFLINE / CONFIGURAR URL"
    }

  Row(
    modifier =
      modifier
        .clip(RoundedCornerShape(50))
        .background(accentColor.copy(alpha = 0.14f))
        .border(1.dp, accentColor.copy(alpha = 0.65f), RoundedCornerShape(50))
        .clickable(onClick = onClick)
        .padding(horizontal = 10.dp, vertical = 5.dp)
        .testTag("server_status_badge"),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.Center,
  ) {
    if (isOnline) {
      PulsingStatusDot(color = StatusOnlineGreen, size = 7.dp, animate = true)
      Spacer(modifier = Modifier.width(6.dp))
    }
    Text(
      text = if (isOnline) "SERVIDOR ONLINE" else label,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 10.sp,
      color = accentColor,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
    if (isOnline) {
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = "●",
        fontSize = 10.sp,
        color = StatusOnlineGreen,
      )
    }
  }
}

@Composable
fun StaffBrandFooter(modifier: Modifier = Modifier) {
  Text(
    text = "PAINEL STAFF — Criado por Raylan",
    style = MaterialTheme.typography.labelSmall,
    fontFamily = FontFamily.Monospace,
    color = TextMuted,
    textAlign = TextAlign.Center,
    modifier = modifier.fillMaxWidth().padding(vertical = 4.dp),
  )
}
