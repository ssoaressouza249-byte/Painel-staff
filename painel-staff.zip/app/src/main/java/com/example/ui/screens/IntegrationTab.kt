package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ManagedApp
import com.example.data.RemoteStaffGuardTemplate
import com.example.ui.components.NeonCard
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkInputBg
import com.example.ui.theme.DeepBlackBg
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite

@Composable
fun IntegrationTab(
  apps: List<ManagedApp>,
  selectedAppId: String,
  firebaseUrl: String,
  onSelectApp: (String) -> Unit,
  onCopiedFeedback: (String) -> Unit,
) {
  val context = LocalContext.current
  val selectedApp = remember(apps, selectedAppId) { apps.find { it.id == selectedAppId } ?: apps.firstOrNull() }
  val generatedCode =
    remember(firebaseUrl, selectedApp) {
      RemoteStaffGuardTemplate.generateKotlinCode(
        firebaseBaseUrl = firebaseUrl,
        targetApp = selectedApp,
      )
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("integration_tab_list"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item(key = "integration_header") {
      NeonCard(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Code,
              contentDescription = "RemoteStaffGuard.kt",
              tint = ElectricBlue,
            )
            Text(
              text = "RemoteStaffGuard.kt",
              style = MaterialTheme.typography.titleLarge,
              color = TextWhite,
              fontWeight = FontWeight.Bold,
            )
          }

          Text(
            text =
              "Código Kotlin pronto para colar nos seus apps clientes: registra instalações, usuários online, verifica manutenção/indisponibilidade e reporta adulteração MT/NP Manager.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextGray,
          )

          Text(
            text = "Selecione o app cliente para gerar o código:",
            style = MaterialTheme.typography.labelMedium,
            color = ElectricBlue,
          )

          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(items = apps, key = { it.id }) { app ->
              val selected = app.id == selectedApp?.id
              FilterChip(
                selected = selected,
                onClick = { onSelectApp(app.id) },
                label = {
                  Text(
                    text = app.name,
                    fontSize = 12.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                  )
                },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NeonPurple,
                    selectedLabelColor = TextWhite,
                    containerColor = DarkCardElevated,
                    labelColor = TextGray,
                  ),
              )
            }
          }

          Button(
            onClick = {
              runCatching {
                  val clipboard =
                    context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                  val clip = ClipData.newPlainText("RemoteStaffGuard.kt", generatedCode)
                  clipboard?.setPrimaryClip(clip)
                }
                .onSuccess {
                  onCopiedFeedback("RemoteStaffGuard.kt copiado para a área de transferência!")
                }
                .onFailure {
                  onCopiedFeedback("Não foi possível acessar a área de transferência.")
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("copy_integration_code_button"),
            shape = RoundedCornerShape(12.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = StatusOnlineGreen,
                contentColor = DeepBlackBg,
              ),
          ) {
            Icon(
              imageVector = Icons.Filled.ContentCopy,
              contentDescription = "Copiar Código",
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Copiar RemoteStaffGuard.kt (1 Clique)",
              fontWeight = FontWeight.ExtraBold,
            )
          }
        }
      }
    }

    item(key = "integration_code_box") {
      NeonCard(modifier = Modifier.fillMaxWidth()) {
        Box(
          modifier =
            Modifier.fillMaxWidth()
              .background(DarkInputBg, RoundedCornerShape(12.dp))
              .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
              .horizontalScroll(rememberScrollState())
              .padding(14.dp)
        ) {
          Text(
            text = generatedCode,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            lineHeight = 16.sp,
            color = TextWhite,
            modifier = Modifier.testTag("integration_code_text"),
          )
        }
      }
    }
  }
}
