package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AntiCloneLog
import com.example.ui.components.NeonCard
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.theme.StatusUnavailableRed
import com.example.ui.theme.StatusWarningYellow
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AntiCloneTab(
  logs: List<AntiCloneLog>,
  onBlockClone: (AntiCloneLog, Boolean) -> Unit,
  onClearLogs: () -> Unit,
) {
  val dateFormatter = remember { SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()) }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("anti_clone_tab_list"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item(key = "anti_clone_header") {
      NeonCard(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f),
          ) {
            Box(
              modifier =
                Modifier.size(42.dp)
                  .background(NeonPurple.copy(alpha = 0.2f), CircleShape)
                  .border(1.dp, ElectricBlue.copy(alpha = 0.6f), CircleShape),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.Security,
                contentDescription = "Segurança Anti-Clone",
                tint = ElectricBlue,
              )
            }
            Column {
              Text(
                text = "Logs MT / NP Manager",
                style = MaterialTheme.typography.titleMedium,
                color = TextWhite,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = "${logs.size} ocorrência(s) registrada(s)",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = if (logs.isEmpty()) StatusOnlineGreen else StatusWarningYellow,
              )
            }
          }

          OutlinedButton(
            onClick = onClearLogs,
            enabled = logs.isNotEmpty(),
            modifier = Modifier.height(44.dp).testTag("clear_anticlone_logs_button"),
            shape = RoundedCornerShape(10.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.DeleteSweep,
              contentDescription = "Limpar Log",
              tint = if (logs.isNotEmpty()) StatusUnavailableRed else TextGray,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Limpar Log",
              color = if (logs.isNotEmpty()) StatusUnavailableRed else TextGray,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
            )
          }
        }
      }
    }

    if (logs.isEmpty()) {
      item(key = "anti_clone_empty") {
        NeonCard(modifier = Modifier.fillMaxWidth()) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.VerifiedUser,
              contentDescription = "Nenhuma adulteração detectada",
              tint = StatusOnlineGreen,
              modifier = Modifier.size(46.dp),
            )
            Text(
              text = "Nenhuma tentativa de clonagem detectada",
              style = MaterialTheme.typography.titleMedium,
              color = TextWhite,
              fontWeight = FontWeight.Bold,
              textAlign = TextAlign.Center,
            )
            Text(
              text =
                "Quando um app cliente com RemoteStaffGuard detectar alteração no MT Manager ou NP Manager, os detalhes aparecerão aqui em tempo real.",
              style = MaterialTheme.typography.bodyMedium,
              color = TextGray,
              textAlign = TextAlign.Center,
            )
          }
        }
      }
    } else {
      items(items = logs, key = { it.id }) { log ->
        AntiCloneLogCard(
          log = log,
          formattedTime = dateFormatter.format(Date(log.timestamp)),
          onToggleBlock = { onBlockClone(log, !log.blocked) },
        )
      }
    }
  }
}

@Composable
private fun AntiCloneLogCard(
  log: AntiCloneLog,
  formattedTime: String,
  onToggleBlock: () -> Unit,
) {
  NeonCard(modifier = Modifier.fillMaxWidth().testTag("anticlone_log_card_${log.id}")) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = Icons.Filled.WarningAmber,
            contentDescription = "Tentativa de Adulteração",
            tint = if (log.blocked) StatusUnavailableRed else StatusWarningYellow,
            modifier = Modifier.size(20.dp),
          )
          Text(
            text = "App Original: ${log.originalApp}",
            style = MaterialTheme.typography.titleMedium,
            color = TextWhite,
            fontWeight = FontWeight.Bold,
          )
        }

        Box(
          modifier =
            Modifier.clip(RoundedCornerShape(50))
              .background(
                if (log.blocked) StatusUnavailableRed.copy(alpha = 0.2f)
                else StatusWarningYellow.copy(alpha = 0.18f)
              )
              .border(
                1.dp,
                if (log.blocked) StatusUnavailableRed else StatusWarningYellow,
                RoundedCornerShape(50),
              )
              .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text = if (log.blocked) "BLOQUEADO" else "DETECTADO",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = if (log.blocked) StatusUnavailableRed else StatusWarningYellow,
          )
        }
      }

      Column(
        modifier =
          Modifier.fillMaxWidth()
            .background(DarkCardElevated, RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
      ) {
        LogDetailRow(label = "Pacote Falso:", value = log.detectedPackage)
        LogDetailRow(label = "Nome Falso:", value = log.detectedName)
        LogDetailRow(label = "Modelo:", value = log.deviceModel)
        LogDetailRow(label = "Data/Hora:", value = formattedTime)
      }

      Button(
        onClick = onToggleBlock,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("block_clone_btn_${log.id}"),
        shape = RoundedCornerShape(12.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = if (log.blocked) DarkCardElevated else StatusUnavailableRed,
            contentColor = TextWhite,
          ),
      ) {
        Icon(
          imageVector = Icons.Filled.Block,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text =
            if (log.blocked) "CLONE BLOQUEADO (TOQUE PARA DESBLOQUEAR)"
            else "BLOQUEAR CLONE REMOTAMENTE",
          fontWeight = FontWeight.ExtraBold,
          fontSize = 12.sp,
        )
      }
    }
  }
}

@Composable
private fun LogDetailRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(
      text = label,
      fontFamily = FontFamily.Monospace,
      fontSize = 11.sp,
      color = TextGray,
    )
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = value,
      fontFamily = FontFamily.Monospace,
      fontSize = 11.sp,
      fontWeight = FontWeight.SemiBold,
      color = TextWhite,
    )
  }
}
