package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.NeonBorderBrush
import com.example.ui.components.NeonCard
import com.example.ui.components.StaffBrandFooter
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DeepBlackBg
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StatusUnavailableRed
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite

@Composable
fun PinLockScreen(
  isPinConfigured: Boolean,
  isConfirmingSetup: Boolean,
  pinError: String?,
  onSubmitPin: (String) -> Unit,
  onResetSetup: () -> Unit,
) {
  var currentInput by remember(isPinConfigured, isConfirmingSetup) { mutableStateOf("") }

  fun appendDigit(digit: String) {
    if (currentInput.length < 6) {
      val updated = currentInput + digit
      currentInput = updated
      if (updated.length == 6) {
        onSubmitPin(updated)
        currentInput = ""
      }
    }
  }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.radialGradient(
            colors = listOf(NeonPurple.copy(alpha = 0.14f), DeepBlackBg)
          )
        )
        .systemBarsPadding()
        .padding(horizontal = 20.dp, vertical = 16.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier = Modifier.fillMaxSize().widthIn(max = 460.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      // Top identity banner
      Text(
        text = "PAINEL STAFF — Criado por Raylan",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        color = ElectricBlue,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(top = 6.dp),
      )

      NeonCard(
        modifier = Modifier.fillMaxWidth(),
        cornerRadius = 20.dp,
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(22.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Box(
            modifier =
              Modifier.size(58.dp)
                .background(
                  Brush.linearGradient(listOf(NeonPurple.copy(alpha = 0.25f), ElectricBlue.copy(alpha = 0.25f))),
                  CircleShape,
                )
                .border(1.2.dp, NeonBorderBrush, CircleShape),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = if (isPinConfigured) Icons.Filled.Lock else Icons.Filled.Shield,
              contentDescription = "Acesso Restrito Staff",
              tint = TextWhite,
              modifier = Modifier.size(28.dp),
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          val heading =
            when {
              !isPinConfigured && !isConfirmingSetup -> "CONFIGURAR PIN STAFF"
              !isPinConfigured && isConfirmingSetup -> "CONFIRME SEU PIN STAFF"
              else -> "ACESSO RESTRITO STAFF"
            }

          val subtitle =
            when {
              !isPinConfigured && !isConfirmingSetup ->
                "Primeiro acesso: defina um PIN numérico de 6 dígitos para proteger o painel."
              !isPinConfigured && isConfirmingSetup ->
                "Digite novamente o mesmo PIN de 6 dígitos para confirmar."
              else -> "Digite seu PIN numérico de 6 dígitos para liberar os controles."
            }

          Text(
            text = heading,
            style = MaterialTheme.typography.titleLarge,
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = TextGray,
            textAlign = TextAlign.Center,
          )

          Spacer(modifier = Modifier.height(22.dp))

          // 6-digit PIN dot indicators
          Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.testTag("pin_dots_row"),
          ) {
            repeat(6) { index ->
              val filled = index < currentInput.length
              Box(
                modifier =
                  Modifier.size(18.dp)
                    .background(
                      color = if (filled) ElectricBlue else DarkCardElevated,
                      shape = CircleShape,
                    )
                    .border(
                      width = 1.2.dp,
                      color = if (filled) NeonPurple else TextGray.copy(alpha = 0.45f),
                      shape = CircleShape,
                    )
              )
            }
          }

          AnimatedVisibility(visible = !pinError.isNullOrBlank()) {
            Text(
              text = pinError.orEmpty(),
              color = StatusUnavailableRed,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold,
              textAlign = TextAlign.Center,
              modifier = Modifier.padding(top = 12.dp).testTag("pin_error_text"),
            )
          }

          if (!isPinConfigured && isConfirmingSetup) {
            TextButton(
              onClick = {
                currentInput = ""
                onResetSetup()
              },
              modifier = Modifier.padding(top = 4.dp),
            ) {
              Text("Refazer primeiro PIN", color = ElectricBlue, fontSize = 12.sp)
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Numeric keypad
          val rows =
            listOf(
              listOf("1", "2", "3"),
              listOf("4", "5", "6"),
              listOf("7", "8", "9"),
            )

          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            rows.forEach { rowDigits ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                rowDigits.forEach { digit ->
                  PinKeyButton(
                    label = digit,
                    onClick = { appendDigit(digit) },
                    modifier = Modifier.weight(1f).testTag("pin_key_$digit"),
                  )
                }
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              PinKeyButton(
                label = "LIMPAR",
                isSecondary = true,
                onClick = { currentInput = "" },
                modifier = Modifier.weight(1f).testTag("pin_key_clear"),
              )
              PinKeyButton(
                label = "0",
                onClick = { appendDigit("0") },
                modifier = Modifier.weight(1f).testTag("pin_key_0"),
              )
              Box(
                modifier =
                  Modifier.weight(1f)
                    .height(54.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkCardElevated)
                    .border(1.dp, NeonPurple.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                    .clickable {
                      if (currentInput.isNotEmpty()) {
                        currentInput = currentInput.dropLast(1)
                      }
                    }
                    .testTag("pin_key_backspace"),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Backspace,
                  contentDescription = "Apagar dígito",
                  tint = TextWhite,
                  modifier = Modifier.size(22.dp),
                )
              }
            }
          }
        }
      }

      StaffBrandFooter()
    }
  }
}

@Composable
private fun PinKeyButton(
  label: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  isSecondary: Boolean = false,
) {
  Box(
    modifier =
      modifier
        .height(54.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(DarkCardElevated)
        .border(
          width = 1.dp,
          brush = NeonBorderBrush,
          shape = RoundedCornerShape(12.dp),
        )
        .clickable(onClick = onClick),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = label,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = if (isSecondary) 12.sp else 20.sp,
      color = if (isSecondary) TextGray else TextWhite,
    )
  }
}
