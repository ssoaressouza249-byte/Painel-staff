package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AnalyticsSnapshot
import com.example.data.AntiCloneLog
import com.example.data.AppStatus
import com.example.data.ManagedApp
import com.example.ui.components.NeonCard
import com.example.ui.components.PulsingStatusDot
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StatusMaintenanceOrange
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.theme.StatusUnavailableRed
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite

@Composable
fun AnalyticsTab(
  apps: List<ManagedApp>,
  timeline: List<AnalyticsSnapshot>,
  antiCloneLogs: List<AntiCloneLog>,
  lastSyncTime: String,
) {
  val totalOnline = remember(apps) { apps.sumOf { it.onlineUsers } }
  val totalAccesses = remember(apps) { apps.sumOf { maxOf(it.totalAccesses, it.totalInstalls) } }
  val blockedClones = remember(antiCloneLogs) { antiCloneLogs.count { it.blocked } }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("analytics_tab_list"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item(key = "analytics_kpi_header") {
      NeonCard(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.Analytics,
                contentDescription = "Analytics em Tempo Real",
                tint = ElectricBlue,
              )
              Text(
                text = "Analytics em Tempo Real",
                style = MaterialTheme.typography.titleLarge,
                color = TextWhite,
                fontWeight = FontWeight.Bold,
              )
            }
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              PulsingStatusDot(color = StatusOnlineGreen, size = 8.dp)
              Text(
                text = if (lastSyncTime.isNotBlank()) lastSyncTime else "AO VIVO",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = StatusOnlineGreen,
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            MiniStatPill("Online Agora", totalOnline.toString(), StatusOnlineGreen, Modifier.weight(1f))
            MiniStatPill("Acessos Totais", totalAccesses.toString(), ElectricBlue, Modifier.weight(1f))
            MiniStatPill("Clones Bloq.", blockedClones.toString(), StatusUnavailableRed, Modifier.weight(1f))
          }
        }
      }
    }

    // Real-Time Line Chart of Online Users / Accesses
    item(key = "realtime_line_chart") {
      NeonCard(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Text(
            text = "Fluxo de Acessos Online (Atualização 5s)",
            style = MaterialTheme.typography.titleMedium,
            color = TextWhite,
            fontWeight = FontWeight.Bold,
          )

          RealtimeLineChart(
            snapshots = timeline,
            modifier = Modifier.fillMaxWidth().height(170.dp),
          )

          if (timeline.isNotEmpty()) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = timeline.first().label,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextGray,
              )
              Text(
                text = "Última leitura: ${timeline.last().label} (${timeline.last().onlineUsers} online)",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = ElectricBlue,
              )
            }
          }
        }
      }
    }

    // Per-App Real-Time Access Bar Chart
    item(key = "per_app_bar_chart") {
      NeonCard(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Text(
            text = "Acessos & Instalações por Aplicativo",
            style = MaterialTheme.typography.titleMedium,
            color = TextWhite,
            fontWeight = FontWeight.Bold,
          )

          val maxVal =
            remember(apps) {
              apps.maxOfOrNull { maxOf(it.totalAccesses, it.totalInstalls, it.onlineUsers) }
                ?.coerceAtLeast(1) ?: 1
            }

          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            apps.forEach { app ->
              val accessValue = maxOf(app.totalAccesses, app.totalInstalls)
              val fraction = (accessValue.toFloat() / maxVal.toFloat()).coerceIn(0f, 1f)
              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Text(
                    text = app.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                  )
                  Text(
                    text = "${app.onlineUsers} on  |  $accessValue acessos",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = ElectricBlue,
                  )
                }
                Box(
                  modifier =
                    Modifier.fillMaxWidth()
                      .height(10.dp)
                      .background(DarkCardElevated, RoundedCornerShape(50))
                ) {
                  Box(
                    modifier =
                      Modifier.fillMaxWidth(fraction.coerceAtLeast(0.03f))
                        .height(10.dp)
                        .background(
                          Brush.horizontalGradient(listOf(NeonPurple, ElectricBlue)),
                          RoundedCornerShape(50),
                        )
                  )
                }
              }
            }
          }
        }
      }
    }

    // Status Distribution Ring Chart
    item(key = "status_donut_chart") {
      val onlineApps = remember(apps) { apps.count { it.status == AppStatus.ONLINE } }
      val maintApps = remember(apps) { apps.count { it.status == AppStatus.MAINTENANCE } }
      val unavailApps = remember(apps) { apps.count { it.status == AppStatus.UNAVAILABLE } }

      NeonCard(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          StatusDonutChart(
            onlineCount = onlineApps,
            maintenanceCount = maintApps,
            unavailableCount = unavailApps,
            modifier = Modifier.size(110.dp),
          )

          Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Text(
              text = "Distribuição dos Apps",
              style = MaterialTheme.typography.titleMedium,
              color = TextWhite,
              fontWeight = FontWeight.Bold,
            )
            LegendItem("Online", onlineApps, StatusOnlineGreen)
            LegendItem("Manutenção", maintApps, StatusMaintenanceOrange)
            LegendItem("Indisponível", unavailApps, StatusUnavailableRed)
          }
        }
      }
    }
  }
}

@Composable
private fun MiniStatPill(
  label: String,
  value: String,
  color: Color,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier.background(DarkCardElevated, RoundedCornerShape(10.dp)).padding(10.dp),
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    Text(
      text = label,
      fontSize = 10.sp,
      color = TextGray,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
    Text(
      text = value,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.ExtraBold,
      fontSize = 18.sp,
      color = color,
    )
  }
}

@Composable
private fun RealtimeLineChart(
  snapshots: List<AnalyticsSnapshot>,
  modifier: Modifier = Modifier,
) {
  if (snapshots.isEmpty()) {
    Box(
      modifier = modifier.background(DarkCardElevated, RoundedCornerShape(12.dp)),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        text = "Conecte ao Firebase para visualizar o gráfico ao vivo",
        style = MaterialTheme.typography.bodyMedium,
        color = TextGray,
      )
    }
    return
  }

  Canvas(
    modifier =
      modifier
        .background(DarkCardElevated, RoundedCornerShape(12.dp))
        .padding(12.dp)
  ) {
    val width = size.width
    val height = size.height
    if (width <= 0f || height <= 0f) return@Canvas

    // Horizontal guide lines
    val gridLines = 4
    for (i in 0..gridLines) {
      val y = height * (i.toFloat() / gridLines.toFloat())
      drawLine(
        color = Color.White.copy(alpha = 0.08f),
        start = Offset(0f, y),
        end = Offset(width, y),
        strokeWidth = 1.dp.toPx(),
      )
    }

    val maxVal = (snapshots.maxOfOrNull { it.onlineUsers } ?: 1).coerceAtLeast(1).toFloat()
    val count = snapshots.size
    val points =
      snapshots.mapIndexed { idx, item ->
        val x = if (count <= 1) width / 2f else (idx.toFloat() / (count - 1).toFloat()) * width
        val normY = (item.onlineUsers.toFloat() / maxVal).coerceIn(0f, 1f)
        val y = height - (normY * (height * 0.85f)) - (height * 0.08f)
        Offset(x, y)
      }

    if (points.size >= 2) {
      val fillPath =
        Path().apply {
          moveTo(points.first().x, height)
          points.forEach { pt -> lineTo(pt.x, pt.y) }
          lineTo(points.last().x, height)
          close()
        }

      drawPath(
        path = fillPath,
        brush =
          Brush.verticalGradient(
            colors = listOf(ElectricBlue.copy(alpha = 0.35f), Color.Transparent)
          ),
      )

      val strokePath =
        Path().apply {
          moveTo(points.first().x, points.first().y)
          for (i in 1 until points.size) {
            lineTo(points[i].x, points[i].y)
          }
        }

      drawPath(
        path = strokePath,
        brush = Brush.horizontalGradient(listOf(NeonPurple, ElectricBlue)),
        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
      )
    }

    points.forEach { pt ->
      drawCircle(color = NeonPurple, radius = 5.dp.toPx(), center = pt)
      drawCircle(color = TextWhite, radius = 2.5.dp.toPx(), center = pt)
    }
  }
}

@Composable
private fun StatusDonutChart(
  onlineCount: Int,
  maintenanceCount: Int,
  unavailableCount: Int,
  modifier: Modifier = Modifier,
) {
  val total = (onlineCount + maintenanceCount + unavailableCount).coerceAtLeast(1)
  Canvas(modifier = modifier) {
    val strokeWidth = 14.dp.toPx()
    val diameter = minOf(size.width, size.height) - strokeWidth
    val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
    val arcSize = Size(diameter, diameter)

    val segments =
      listOf(
        onlineCount to StatusOnlineGreen,
        maintenanceCount to StatusMaintenanceOrange,
        unavailableCount to StatusUnavailableRed,
      )

    var startAngle = -90f
    segments.forEach { (count, color) ->
      if (count > 0) {
        val sweep = (count.toFloat() / total.toFloat()) * 360f
        drawArc(
          color = color,
          startAngle = startAngle,
          sweepAngle = sweep,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokeWidth, cap = StrokeCap.Butt),
        )
        startAngle += sweep
      }
    }
  }
}

@Composable
private fun LegendItem(label: String, count: Int, color: Color) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Box(modifier = Modifier.size(10.dp).background(color, CircleShape))
    Text(
      text = "$label: $count",
      fontFamily = FontFamily.Monospace,
      fontSize = 12.sp,
      color = TextWhite,
    )
  }
}
