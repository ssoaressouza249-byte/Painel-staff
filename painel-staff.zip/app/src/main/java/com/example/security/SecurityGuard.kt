package com.example.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.SecurityTamperDarkRed
import com.example.ui.theme.SecurityTamperRed
import com.example.ui.theme.TextWhite

data class SecurityCheckResult(
  val isAuthentic: Boolean,
  val detectedPackage: String,
  val detectedAppName: String,
  val reason: String,
)

object SecurityGuard {
  const val EXPECTED_PACKAGE = "com.raylan.painelstaff"
  const val EXPECTED_NAME_TOKEN = "Painel Staff"

  fun verifyIntegrity(context: Context): SecurityCheckResult {
    return runCatching {
        val actualPackage = context.packageName.orEmpty()
        val labelFromPackageManager =
          runCatching {
              context.applicationInfo.loadLabel(context.packageManager).toString()
            }
            .getOrDefault("")
        val labelFromRes = runCatching { context.getString(R.string.app_name) }.getOrDefault("")
        val resolvedName = labelFromPackageManager.ifBlank { labelFromRes }

        val packageValid = actualPackage == EXPECTED_PACKAGE
        val nameValid =
          labelFromPackageManager.contains(EXPECTED_NAME_TOKEN, ignoreCase = false) &&
            labelFromRes.contains(EXPECTED_NAME_TOKEN, ignoreCase = false)

        val reason =
          when {
            !packageValid && !nameValid ->
              "Pacote ($actualPackage) e Nome ($resolvedName) foram adulterados."
            !packageValid -> "Pacote adulterado: esperado $EXPECTED_PACKAGE, detectado $actualPackage."
            !nameValid -> "Nome do aplicativo adulterado: $resolvedName."
            else -> "Integridade verificada."
          }

        SecurityCheckResult(
          isAuthentic = packageValid && nameValid,
          detectedPackage = actualPackage,
          detectedAppName = resolvedName,
          reason = reason,
        )
      }
      .getOrElse { error ->
        SecurityCheckResult(
          isAuthentic = false,
          detectedPackage = "desconhecido",
          detectedAppName = "desconhecido",
          reason = "Falha crítica na verificação de integridade: ${error.message ?: "erro"}",
        )
      }
  }

  fun launchUninstall(context: Context) {
    runCatching {
      val packageUri = Uri.parse("package:${context.packageName}")
      val uninstallIntent =
        Intent(Intent.ACTION_DELETE, packageUri).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(uninstallIntent)
    }
  }
}

@Composable
fun SecurityTamperScreen(result: SecurityCheckResult) {
  val context = LocalContext.current

  // Lock hardware/gesture back button completely when tampering is detected
  BackHandler(enabled = true) {}

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(SecurityTamperRed, SecurityTamperDarkRed, SecurityTamperRed)
          )
        )
        .systemBarsPadding()
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(Color(0x40000000), RoundedCornerShape(20.dp))
          .border(1.5.dp, Color(0x80FFFFFF), RoundedCornerShape(20.dp))
          .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Box(
        modifier =
          Modifier.size(84.dp)
            .background(Color(0x33FFFFFF), CircleShape)
            .border(2.dp, TextWhite, CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.GppBad,
          contentDescription = "Alerta de Adulteração",
          tint = TextWhite,
          modifier = Modifier.size(48.dp),
        )
      }

      Text(
        text = "MODIFICAÇÃO NÃO AUTORIZADA DETECTADA",
        style = MaterialTheme.typography.headlineSmall,
        color = TextWhite,
        fontWeight = FontWeight.ExtraBold,
        textAlign = TextAlign.Center,
      )

      Text(
        text =
          "Este aplicativo foi protegido pelo SecurityGuard. Modificações via MT Manager, NP Manager ou clonagem de pacote bloqueiam o acesso permanentemente.",
        style = MaterialTheme.typography.bodyLarge,
        color = Color(0xFFFFEBEE),
        textAlign = TextAlign.Center,
      )

      Column(
        modifier =
          Modifier.fillMaxWidth()
            .background(Color(0x55000000), RoundedCornerShape(12.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
          text = "PACOTE DETECTADO: ${result.detectedPackage}",
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp,
          color = Color(0xFFFFCDD2),
        )
        Text(
          text = "NOME DETECTADO: ${result.detectedAppName}",
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp,
          color = Color(0xFFFFCDD2),
        )
        Text(
          text = "MOTIVO: ${result.reason}",
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp,
          color = TextWhite,
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Button(
        onClick = { SecurityGuard.launchUninstall(context) },
        modifier = Modifier.fillMaxWidth().height(54.dp).testTag("uninstall_now_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = TextWhite, contentColor = SecurityTamperRed),
      ) {
        Icon(
          imageVector = Icons.Filled.DeleteForever,
          contentDescription = "Desinstalar Agora",
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.size(8.dp))
        Text(
          text = "DESINSTALAR AGORA",
          fontWeight = FontWeight.ExtraBold,
          letterSpacing = 0.8.sp,
        )
      }
    }
  }
}
