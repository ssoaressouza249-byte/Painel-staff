package com.example.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

class LocalPrefsStorage(context: Context) {
  private val prefs: SharedPreferences? =
    runCatching { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }.getOrNull()

  fun getFirebaseUrl(): String {
    return runCatching { prefs?.getString(KEY_FIREBASE_URL, "")?.trim().orEmpty() }.getOrDefault("")
  }

  fun saveFirebaseUrl(url: String) {
    runCatching { prefs?.edit()?.putString(KEY_FIREBASE_URL, url.trim())?.apply() }
  }

  fun hasPinConfigured(): Boolean {
    return runCatching { !prefs?.getString(KEY_STAFF_PIN_HASH, null).isNullOrBlank() }
      .getOrDefault(false)
  }

  fun savePin(pin: String): Boolean {
    return runCatching {
        if (pin.length != 6 || !pin.all { it.isDigit() }) return@runCatching false
        val hashed = hashPin(pin)
        prefs?.edit()?.putString(KEY_STAFF_PIN_HASH, hashed)?.apply()
        true
      }
      .getOrDefault(false)
  }

  fun verifyPin(pin: String): Boolean {
    return runCatching {
        val storedHash = prefs?.getString(KEY_STAFF_PIN_HASH, null) ?: return@runCatching false
        storedHash == hashPin(pin)
      }
      .getOrDefault(false)
  }

  private fun hashPin(pin: String): String {
    return runCatching {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("painel_staff_salt_$pin".toByteArray(Charsets.UTF_8))
        bytes.joinToString("") { "%02x".format(it) }
      }
      .getOrDefault(pin)
  }

  companion object {
    private const val PREFS_NAME = "painel_staff_secure_prefs"
    private const val KEY_FIREBASE_URL = "firebase_rtdb_url"
    private const val KEY_STAFF_PIN_HASH = "staff_pin_hash_v1"
  }
}
