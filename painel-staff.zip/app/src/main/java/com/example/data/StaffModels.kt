package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.StatusMaintenanceOrange
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.theme.StatusUnavailableRed

enum class AppStatus(
  val wireValue: String,
  val label: String,
  val color: Color,
) {
  ONLINE("ONLINE", "ONLINE", StatusOnlineGreen),
  MAINTENANCE("MANUTENCAO", "MANUTENÇÃO", StatusMaintenanceOrange),
  UNAVAILABLE("INDISPONIVEL", "INDISPONÍVEL", StatusUnavailableRed);

  companion object {
    fun fromWire(value: String?): AppStatus {
      return when (value?.uppercase()?.trim()) {
        "MANUTENCAO",
        "MANUTENÇÃO",
        "MAINTENANCE" -> MAINTENANCE
        "INDISPONIVEL",
        "INDISPONÍVEL",
        "UNAVAILABLE",
        "OFFLINE" -> UNAVAILABLE
        else -> ONLINE
      }
    }
  }
}

data class ManagedApp(
  val id: String,
  val name: String,
  val packageName: String,
  val status: AppStatus = AppStatus.ONLINE,
  val noticeMessage: String = "",
  val totalInstalls: Int = 0,
  val onlineUsers: Int = 0,
  val totalAccesses: Int = 0,
  val updatedAt: Long = 0L,
)

data class GlobalNotice(
  val message: String = "",
  val active: Boolean = false,
  val updatedAt: Long = 0L,
)

data class AntiCloneLog(
  val id: String,
  val originalApp: String,
  val detectedPackage: String,
  val detectedName: String,
  val deviceModel: String,
  val timestamp: Long,
  val blocked: Boolean,
)

data class AnalyticsSnapshot(
  val label: String,
  val onlineUsers: Int,
  val totalAccesses: Int,
  val timestamp: Long,
)

data class StaffDatabaseSnapshot(
  val apps: List<ManagedApp>,
  val globalNotice: GlobalNotice,
  val antiCloneLogs: List<AntiCloneLog>,
  val serverTimeline: List<AnalyticsSnapshot>,
)

object DefaultAppsSeed {
  fun createInitialApps(nowMillis: Long = System.currentTimeMillis()): List<ManagedApp> =
    listOf(
      ManagedApp(
        id = "grx_resolucao",
        name = "GRX Resolução",
        packageName = "com.raylan.grxresolucao",
        status = AppStatus.ONLINE,
        noticeMessage = "",
        totalInstalls = 0,
        onlineUsers = 0,
        totalAccesses = 0,
        updatedAt = nowMillis,
      ),
      ManagedApp(
        id = "gfx_boost",
        name = "GFX Boost",
        packageName = "com.raylan.gfxboost",
        status = AppStatus.ONLINE,
        noticeMessage = "",
        totalInstalls = 0,
        onlineUsers = 0,
        totalAccesses = 0,
        updatedAt = nowMillis,
      ),
      ManagedApp(
        id = "fangx",
        name = "Fangx",
        packageName = "com.raylan.fangx",
        status = AppStatus.ONLINE,
        noticeMessage = "",
        totalInstalls = 0,
        onlineUsers = 0,
        totalAccesses = 0,
        updatedAt = nowMillis,
      ),
      ManagedApp(
        id = "boneco_lento",
        name = "Boneco Lento",
        packageName = "com.raylan.bonecolento",
        status = AppStatus.ONLINE,
        noticeMessage = "",
        totalInstalls = 0,
        onlineUsers = 0,
        totalAccesses = 0,
        updatedAt = nowMillis,
      ),
      ManagedApp(
        id = "gerador_sensix",
        name = "Gerador Sensix",
        packageName = "com.raylan.geradorsensix",
        status = AppStatus.ONLINE,
        noticeMessage = "",
        totalInstalls = 0,
        onlineUsers = 0,
        totalAccesses = 0,
        updatedAt = nowMillis,
      ),
      ManagedApp(
        id = "rayze_hud_fps_pro",
        name = "Rayze HUD & FPS Pro",
        packageName = "com.raylan.rayzehud",
        status = AppStatus.ONLINE,
        noticeMessage = "",
        totalInstalls = 0,
        onlineUsers = 0,
        totalAccesses = 0,
        updatedAt = nowMillis,
      ),
      ManagedApp(
        id = "grx_2x",
        name = "GRX 2x",
        packageName = "com.raylan.grx2x",
        status = AppStatus.ONLINE,
        noticeMessage = "",
        totalInstalls = 0,
        onlineUsers = 0,
        totalAccesses = 0,
        updatedAt = nowMillis,
      ),
      ManagedApp(
        id = "assistente_ai",
        name = "Assistente AI",
        packageName = "com.raylan.assistenteai",
        status = AppStatus.ONLINE,
        noticeMessage = "",
        totalInstalls = 0,
        onlineUsers = 0,
        totalAccesses = 0,
        updatedAt = nowMillis,
      ),
    )
}
