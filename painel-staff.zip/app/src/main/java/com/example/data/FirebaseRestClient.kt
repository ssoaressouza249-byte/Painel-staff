package com.example.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class FirebaseRestClient {
  private val client: OkHttpClient =
    OkHttpClient.Builder()
      .connectTimeout(12, TimeUnit.SECONDS)
      .readTimeout(12, TimeUnit.SECONDS)
      .writeTimeout(12, TimeUnit.SECONDS)
      .build()

  private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

  fun normalizeBaseUrl(rawUrl: String): String {
    return runCatching {
        var cleaned = rawUrl.trim()
        if (cleaned.isEmpty()) return@runCatching ""
        if (!cleaned.startsWith("http://") && !cleaned.startsWith("https://")) {
          cleaned = "https://$cleaned"
        }
        if (cleaned.endsWith(".json")) {
          cleaned = cleaned.removeSuffix(".json")
        }
        cleaned.trimEnd('/')
      }
      .getOrDefault("")
  }

  suspend fun fetchOrInitializeDatabase(baseUrl: String): Result<StaffDatabaseSnapshot> =
    withContext(Dispatchers.IO) {
      runCatching {
        val normalized = normalizeBaseUrl(baseUrl)
        require(normalized.startsWith("https://") || normalized.startsWith("http://")) {
          "URL do Firebase inválida."
        }

        val rootUrl = "$normalized/painel_staff.json"
        val bodyText = executeGet(rootUrl).getOrThrow().trim()

        val isEmptyDb =
          bodyText.isEmpty() ||
            bodyText == "null" ||
            bodyText == "{}" ||
            runCatching {
                val json = JSONObject(bodyText)
                !json.has("apps") || json.optJSONObject("apps")?.length() == 0
              }
              .getOrDefault(true)

        if (isEmptyDb) {
          val initialJson = buildInitialDatabaseJson()
          executePut(rootUrl, initialJson.toString()).getOrThrow()
          parseSnapshot(initialJson)
        } else {
          parseSnapshot(JSONObject(bodyText))
        }
      }
    }

  suspend fun fetchSnapshot(baseUrl: String): Result<StaffDatabaseSnapshot> =
    withContext(Dispatchers.IO) {
      runCatching {
        val normalized = normalizeBaseUrl(baseUrl)
        require(normalized.isNotEmpty()) { "URL do Firebase não configurada." }
        val bodyText = executeGet("$normalized/painel_staff.json").getOrThrow().trim()
        if (bodyText.isEmpty() || bodyText == "null") {
          val initialJson = buildInitialDatabaseJson()
          executePut("$normalized/painel_staff.json", initialJson.toString()).getOrThrow()
          parseSnapshot(initialJson)
        } else {
          parseSnapshot(JSONObject(bodyText))
        }
      }
    }

  suspend fun updateAppStatus(
    baseUrl: String,
    appId: String,
    status: AppStatus,
    noticeMessage: String,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val normalized = normalizeBaseUrl(baseUrl)
        require(normalized.isNotEmpty()) { "URL do Firebase não configurada." }
        val payload =
          JSONObject().apply {
            put("status", status.wireValue)
            put("noticeMessage", noticeMessage)
            put("updatedAt", System.currentTimeMillis())
          }
        executePatch("$normalized/painel_staff/apps/$appId.json", payload.toString()).getOrThrow()
        Unit
      }
    }

  suspend fun updateAppNotice(
    baseUrl: String,
    appId: String,
    noticeMessage: String,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val normalized = normalizeBaseUrl(baseUrl)
        require(normalized.isNotEmpty()) { "URL do Firebase não configurada." }
        val payload =
          JSONObject().apply {
            put("noticeMessage", noticeMessage)
            put("updatedAt", System.currentTimeMillis())
          }
        executePatch("$normalized/painel_staff/apps/$appId.json", payload.toString()).getOrThrow()
        Unit
      }
    }

  suspend fun upsertApp(baseUrl: String, app: ManagedApp): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val normalized = normalizeBaseUrl(baseUrl)
        require(normalized.isNotEmpty()) { "URL do Firebase não configurada." }
        val payload = appToJson(app)
        executePut("$normalized/painel_staff/apps/${app.id}.json", payload.toString()).getOrThrow()
        Unit
      }
    }

  suspend fun sendGlobalNotice(baseUrl: String, notice: GlobalNotice): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val normalized = normalizeBaseUrl(baseUrl)
        require(normalized.isNotEmpty()) { "URL do Firebase não configurada." }
        val payload =
          JSONObject().apply {
            put("message", notice.message)
            put("active", notice.active)
            put("updatedAt", notice.updatedAt)
          }
        executePut("$normalized/painel_staff/global_notice.json", payload.toString()).getOrThrow()
        Unit
      }
    }

  suspend fun setCloneBlocked(
    baseUrl: String,
    log: AntiCloneLog,
    blocked: Boolean,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val normalized = normalizeBaseUrl(baseUrl)
        require(normalized.isNotEmpty()) { "URL do Firebase não configurada." }

        val logPatch =
          JSONObject().apply {
            put("blocked", blocked)
            put("blockedAt", System.currentTimeMillis())
          }
        executePatch(
            "$normalized/painel_staff/anti_clone_logs/${log.id}.json",
            logPatch.toString(),
          )
          .getOrThrow()

        val safePkgKey = sanitizeFirebaseKey(log.detectedPackage.ifBlank { log.id })
        if (blocked) {
          val blockNode =
            JSONObject().apply {
              put("blocked", true)
              put("originalApp", log.originalApp)
              put("detectedPackage", log.detectedPackage)
              put("detectedName", log.detectedName)
              put("deviceModel", log.deviceModel)
              put("updatedAt", System.currentTimeMillis())
            }
          executePut(
              "$normalized/painel_staff/blocked_clones/$safePkgKey.json",
              blockNode.toString(),
            )
            .getOrThrow()
        } else {
          executeDelete("$normalized/painel_staff/blocked_clones/$safePkgKey.json").getOrThrow()
        }
        Unit
      }
    }

  suspend fun clearAntiCloneLogs(baseUrl: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val normalized = normalizeBaseUrl(baseUrl)
        require(normalized.isNotEmpty()) { "URL do Firebase não configurada." }
        executeDelete("$normalized/painel_staff/anti_clone_logs.json").getOrThrow()
        Unit
      }
    }

  private fun executeGet(url: String): Result<String> = runCatching {
    val request = Request.Builder().url(url).get().build()
    client.newCall(request).execute().use { response ->
      val body = response.body?.string().orEmpty()
      if (!response.isSuccessful) {
        error("HTTP ${response.code}: ${body.take(160)}")
      }
      body
    }
  }

  private fun executePut(url: String, jsonBody: String): Result<String> = runCatching {
    val body = jsonBody.toRequestBody(jsonMediaType)
    val request = Request.Builder().url(url).put(body).build()
    client.newCall(request).execute().use { response ->
      val text = response.body?.string().orEmpty()
      if (!response.isSuccessful) {
        error("HTTP ${response.code}: ${text.take(160)}")
      }
      text
    }
  }

  private fun executePatch(url: String, jsonBody: String): Result<String> = runCatching {
    val body = jsonBody.toRequestBody(jsonMediaType)
    val request = Request.Builder().url(url).patch(body).build()
    client.newCall(request).execute().use { response ->
      val text = response.body?.string().orEmpty()
      if (!response.isSuccessful) {
        error("HTTP ${response.code}: ${text.take(160)}")
      }
      text
    }
  }

  private fun executeDelete(url: String): Result<String> = runCatching {
    val request = Request.Builder().url(url).delete().build()
    client.newCall(request).execute().use { response ->
      val text = response.body?.string().orEmpty()
      if (!response.isSuccessful) {
        error("HTTP ${response.code}: ${text.take(160)}")
      }
      text
    }
  }

  private fun buildInitialDatabaseJson(): JSONObject {
    val now = System.currentTimeMillis()
    val appsJson = JSONObject()
    DefaultAppsSeed.createInitialApps(now).forEach { app -> appsJson.put(app.id, appToJson(app)) }

    val globalNoticeJson =
      JSONObject().apply {
        put("message", "")
        put("active", false)
        put("updatedAt", now)
      }

    return JSONObject().apply {
      put("apps", appsJson)
      put("global_notice", globalNoticeJson)
      put("initializedAt", now)
      put("owner", "PAINEL STAFF — Criado por Raylan")
    }
  }

  private fun appToJson(app: ManagedApp): JSONObject {
    return JSONObject().apply {
      put("id", app.id)
      put("name", app.name)
      put("packageName", app.packageName)
      put("status", app.status.wireValue)
      put("noticeMessage", app.noticeMessage)
      put("totalInstalls", app.totalInstalls)
      put("onlineUsers", app.onlineUsers)
      put("totalAccesses", app.totalAccesses)
      put("updatedAt", app.updatedAt)
    }
  }

  private fun parseSnapshot(root: JSONObject): StaffDatabaseSnapshot {
    val appsList = mutableListOf<ManagedApp>()
    val appsObj = root.optJSONObject("apps")
    if (appsObj != null) {
      val keys = appsObj.keys()
      while (keys.hasNext()) {
        val key = keys.next()
        val item = appsObj.optJSONObject(key) ?: continue
        val sessionsCount = item.optJSONObject("active_sessions")?.length() ?: 0
        val rawOnline = item.optInt("onlineUsers", 0)
        val effectiveOnline = maxOf(rawOnline, sessionsCount)
        val rawInstalls = item.optInt("totalInstalls", 0)
        val rawAccesses = item.optInt("totalAccesses", rawInstalls)
        appsList.add(
          ManagedApp(
            id = item.optString("id", key).ifBlank { key },
            name = item.optString("name", key),
            packageName = item.optString("packageName", ""),
            status = AppStatus.fromWire(item.optString("status", "ONLINE")),
            noticeMessage = item.optString("noticeMessage", ""),
            totalInstalls = rawInstalls,
            onlineUsers = effectiveOnline,
            totalAccesses = rawAccesses,
            updatedAt = item.optLong("updatedAt", 0L),
          )
        )
      }
    }

    // Preserve preferred order for default apps, then custom apps alphabetically
    val seedOrder = DefaultAppsSeed.createInitialApps().mapIndexed { index, app -> app.id to index }.toMap()
    appsList.sortWith(
      compareBy<ManagedApp> { seedOrder[it.id] ?: Int.MAX_VALUE }.thenBy { it.name.lowercase() }
    )

    val noticeObj = root.optJSONObject("global_notice")
    val globalNotice =
      GlobalNotice(
        message = noticeObj?.optString("message", "").orEmpty(),
        active = noticeObj?.optBoolean("active", false) ?: false,
        updatedAt = noticeObj?.optLong("updatedAt", 0L) ?: 0L,
      )

    val logsList = mutableListOf<AntiCloneLog>()
    val logsObj = root.optJSONObject("anti_clone_logs")
    if (logsObj != null) {
      val keys = logsObj.keys()
      while (keys.hasNext()) {
        val key = keys.next()
        val item = logsObj.optJSONObject(key) ?: continue
        logsList.add(
          AntiCloneLog(
            id = key,
            originalApp = item.optString("originalApp", "App Desconhecido"),
            detectedPackage = item.optString("detectedPackage", "pacote.desconhecido"),
            detectedName = item.optString("detectedName", "Nome Desconhecido"),
            deviceModel = item.optString("deviceModel", "Dispositivo Android"),
            timestamp = item.optLong("timestamp", System.currentTimeMillis()),
            blocked = item.optBoolean("blocked", false),
          )
        )
      }
    }
    logsList.sortByDescending { it.timestamp }

    val timelineList = mutableListOf<AnalyticsSnapshot>()
    val analyticsObj = root.optJSONObject("analytics")
    if (analyticsObj != null) {
      val keys = analyticsObj.keys()
      val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
      while (keys.hasNext()) {
        val key = keys.next()
        val item = analyticsObj.optJSONObject(key) ?: continue
        val ts = item.optLong("timestamp", 0L)
        val lbl =
          item.optString("label", "").ifBlank {
            if (ts > 0L) formatter.format(Date(ts)) else key
          }
        timelineList.add(
          AnalyticsSnapshot(
            label = lbl,
            onlineUsers = item.optInt("onlineUsers", 0),
            totalAccesses = item.optInt("totalAccesses", 0),
            timestamp = ts,
          )
        )
      }
      timelineList.sortBy { it.timestamp }
    }

    return StaffDatabaseSnapshot(
      apps = appsList,
      globalNotice = globalNotice,
      antiCloneLogs = logsList,
      serverTimeline = timelineList,
    )
  }

  private fun sanitizeFirebaseKey(raw: String): String {
    return raw.replace(Regex("[.#$\\[\\]/]"), "_")
  }
}
