package com.example.data

object RemoteStaffGuardTemplate {
  fun generateKotlinCode(
    firebaseBaseUrl: String,
    targetApp: ManagedApp?,
  ): String {
    val cleanUrl =
      firebaseBaseUrl
        .trim()
        .removeSuffix("/")
        .removeSuffix(".json")
        .ifBlank { "https://SEU-PROJETO-default-rtdb.firebaseio.com" }

    val appId = targetApp?.id ?: "grx_resolucao"
    val appName = targetApp?.name ?: "GRX Resolução"
    val expectedPkg = targetApp?.packageName?.ifBlank { "com.raylan.$appId" } ?: "com.raylan.grxresolucao"

    return """
package com.raylan.client.security

import android.content.Context
import android.os.Build
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * PAINEL STAFF — Criado por Raylan
 * RemoteStaffGuard.kt — Cole este arquivo no seu aplicativo cliente.
 * Requer apenas OkHttp e permissão INTERNET no AndroidManifest.xml.
 */
object RemoteStaffGuard {

    private const val FIREBASE_BASE_URL = "$cleanUrl"
    private const val APP_ID = "$appId"
    private const val EXPECTED_APP_NAME = "$appName"
    private const val EXPECTED_PACKAGE_NAME = "$expectedPkg"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    data class RemoteControlState(
        val allowedToRun: Boolean,
        val status: String,
        val appNotice: String,
        val globalNotice: String,
        val globalNoticeActive: Boolean,
        val blockedAsClone: Boolean,
        val tamperDetected: Boolean
    )

    suspend fun syncAndProtect(context: Context): RemoteControlState = withContext(Dispatchers.IO) {
        runCatching {
            val actualPackage = context.packageName.orEmpty()
            val actualName = runCatching {
                context.applicationInfo.loadLabel(context.packageManager).toString()
            }.getOrDefault("")

            val isTampered = actualPackage != EXPECTED_PACKAGE_NAME ||
                !actualName.contains(EXPECTED_APP_NAME, ignoreCase = true)

            if (isTampered) {
                reportTampering(
                    detectedPackage = actualPackage,
                    detectedName = actualName
                )
                return@runCatching RemoteControlState(
                    allowedToRun = false,
                    status = "BLOQUEADO",
                    appNotice = "Aplicativo adulterado detectado.",
                    globalNotice = "",
                    globalNoticeActive = false,
                    blockedAsClone = true,
                    tamperDetected = true
                )
            }

            // 1. Verifica se o pacote/clone foi bloqueado remotamente no Painel Staff
            val safePkgKey = actualPackage.replace(Regex("[.#$\\[\\]/]"), "_")
            val blockRes = getJson("${'$'}FIREBASE_BASE_URL/painel_staff/blocked_clones/${'$'}safePkgKey.json")
            val isRemotelyBlocked = blockRes?.optBoolean("blocked", false) == true

            if (isRemotelyBlocked) {
                return@runCatching RemoteControlState(
                    allowedToRun = false,
                    status = "BLOQUEADO",
                    appNotice = "Acesso bloqueado remotamente pelo Painel Staff.",
                    globalNotice = "",
                    globalNoticeActive = false,
                    blockedAsClone = true,
                    tamperDetected = false
                )
            }

            // 2. Registra instalação única e incrementa acessos online
            registerInstallAndHeartbeat(context)

            // 3. Busca status atual do app e aviso global
            val appJson = getJson("${'$'}FIREBASE_BASE_URL/painel_staff/apps/${'$'}APP_ID.json")
            val globalJson = getJson("${'$'}FIREBASE_BASE_URL/painel_staff/global_notice.json")

            val status = appJson?.optString("status", "ONLINE") ?: "ONLINE"
            val appNotice = appJson?.optString("noticeMessage", "") ?: ""
            val globalMsg = globalJson?.optString("message", "") ?: ""
            val globalActive = globalJson?.optBoolean("active", false) ?: false

            val canRun = status == "ONLINE"

            RemoteControlState(
                allowedToRun = canRun,
                status = status,
                appNotice = appNotice,
                globalNotice = globalMsg,
                globalNoticeActive = globalActive,
                blockedAsClone = false,
                tamperDetected = false
            )
        }.getOrElse {
            RemoteControlState(
                allowedToRun = true,
                status = "ONLINE",
                appNotice = "",
                globalNotice = "",
                globalNoticeActive = false,
                blockedAsClone = false,
                tamperDetected = false
            )
        }
    }

    private fun registerInstallAndHeartbeat(context: Context) {
        runCatching {
            val prefs = context.getSharedPreferences("remote_staff_guard_prefs", Context.MODE_PRIVATE)
            val deviceId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                ?.ifBlank { "dev_${'$'}{System.currentTimeMillis()}" } ?: "dev_unknown"

            val appJson = getJson("${'$'}FIREBASE_BASE_URL/painel_staff/apps/${'$'}APP_ID.json")
            val currentInstalls = appJson?.optInt("totalInstalls", 0) ?: 0
            val currentAccesses = appJson?.optInt("totalAccesses", 0) ?: 0

            val alreadyCounted = prefs.getBoolean("install_counted_${'$'}APP_ID", false)
            val nextInstalls = if (alreadyCounted) currentInstalls else currentInstalls + 1

            // Registra sessão ativa para contagem precisa de usuários online
            val sessionPayload = JSONObject().apply {
                put("device", "${'$'}{Build.MANUFACTURER} ${'$'}{Build.MODEL}".trim())
                put("lastSeen", System.currentTimeMillis())
            }
            putJson(
                "${'$'}FIREBASE_BASE_URL/painel_staff/apps/${'$'}APP_ID/active_sessions/${'$'}deviceId.json",
                sessionPayload.toString()
            )

            val sessionsJson = getJson("${'$'}FIREBASE_BASE_URL/painel_staff/apps/${'$'}APP_ID/active_sessions.json")
            val activeCount = sessionsJson?.length() ?: 1

            val patchPayload = JSONObject().apply {
                put("totalInstalls", nextInstalls)
                put("onlineUsers", activeCount)
                put("totalAccesses", currentAccesses + 1)
                put("updatedAt", System.currentTimeMillis())
            }
            patchJson("${'$'}FIREBASE_BASE_URL/painel_staff/apps/${'$'}APP_ID.json", patchPayload.toString())

            if (!alreadyCounted) {
                prefs.edit().putBoolean("install_counted_${'$'}APP_ID", true).apply()
            }
        }
    }

    private fun reportTampering(detectedPackage: String, detectedName: String) {
        runCatching {
            val deviceModel = "${'$'}{Build.MANUFACTURER} ${'$'}{Build.MODEL}".trim()
            val payload = JSONObject().apply {
                put("originalApp", EXPECTED_APP_NAME)
                put("detectedPackage", detectedPackage)
                put("detectedName", detectedName)
                put("deviceModel", deviceModel)
                put("timestamp", System.currentTimeMillis())
                put("blocked", false)
            }
            postJson("${'$'}FIREBASE_BASE_URL/painel_staff/anti_clone_logs.json", payload.toString())
        }
    }

    private fun getJson(url: String): JSONObject? {
        return runCatching {
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { res ->
                val text = res.body?.string().orEmpty()
                if (!res.isSuccessful || text.isBlank() || text == "null") null else JSONObject(text)
            }
        }.getOrNull()
    }

    private fun putJson(url: String, bodyStr: String) {
        runCatching {
            val req = Request.Builder().url(url).put(bodyStr.toRequestBody(jsonMediaType)).build()
            client.newCall(req).execute().close()
        }
    }

    private fun patchJson(url: String, bodyStr: String) {
        runCatching {
            val req = Request.Builder().url(url).patch(bodyStr.toRequestBody(jsonMediaType)).build()
            client.newCall(req).execute().close()
        }
    }

    private fun postJson(url: String, bodyStr: String) {
        runCatching {
            val req = Request.Builder().url(url).post(bodyStr.toRequestBody(jsonMediaType)).build()
            client.newCall(req).execute().close()
        }
    }
}
""".trimIndent()
  }
}
